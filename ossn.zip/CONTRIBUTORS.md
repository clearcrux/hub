The following developers contributed to this project:

* Ethel M. Ward
* Sophia Mahler
* Sathish Kumar
* Arsalan Shah
* Mike Wagner
* Ralph Pfeifer
* Uwe Kaestner
* Jerry L. McCord
* Anthony E. Sikora
* Charles E. Lawler
* Shaf Brady Hussain
* Softaculous Team
* Michael Zülsdorff
* Bishop Gregory Godsey (https://github.com/bishopgodsey)
* Roberto Vaccaro (https://github.com/robertito13)
* Huck Jones (https://github.com/huckleberrypie)
* TheGameHHH (https://github.com/TheGameHHH)
* Julien Jehannet (https://github.com/jjehannet)
* Tomáš Votruba (https://github.com/TomasVotruba)
* Eric F. (https://www.opensource-socialnetwork.org/u/ctlui)
